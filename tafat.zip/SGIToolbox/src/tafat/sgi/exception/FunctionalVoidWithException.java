package tafat.sgi.exception;

public interface FunctionalVoidWithException {
    void execute() throws Exception;
}
