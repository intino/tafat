package tafat.sgi.exception;

public interface FunctionalWithoutException<Input>{
    Input execute();
}
