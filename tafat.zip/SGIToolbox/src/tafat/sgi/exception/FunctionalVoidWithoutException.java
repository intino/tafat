package tafat.sgi.exception;

public interface FunctionalVoidWithoutException {
    public void execute();
}
