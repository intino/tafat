package tafat.sgi.http.connection.controller;

public interface HttpService {
    void start();
}
