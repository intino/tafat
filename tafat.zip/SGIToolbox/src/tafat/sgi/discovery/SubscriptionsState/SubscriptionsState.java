package tafat.sgi.discovery.SubscriptionsState;

import tafat.sgi.discovery.connection.NetInformation;

public interface SubscriptionsState {
    public boolean exitsNetInformation(NetInformation netInformation);
}
