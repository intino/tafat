package tafat.framework.integration.simulation;

public class SimulationObject {
    String name;
    String objectId;

    public SimulationObject(String name, String id) {
        this.name = name;
        this.objectId = id;
    }
}
