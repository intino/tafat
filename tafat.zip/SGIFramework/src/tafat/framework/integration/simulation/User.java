package tafat.framework.integration.simulation;

public class User {
    private final String username;

    public User(String username) {
        this.username = username;
    }

    public String username() {
        return username;
    }
}
