package tafat.framework.services;

public interface FrameworkService {
}
