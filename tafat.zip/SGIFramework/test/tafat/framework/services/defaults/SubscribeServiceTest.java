package tafat.framework.services.defaults;

public class SubscribeServiceTest {


}
