package tafat.framework.mockServices.classToService;

import tafat.framework.services.SubscriptionService;
import tafat.sgi.http.connection.model.conection.Request;
import tafat.sgi.http.connection.model.conection.Response;

public class SubscribeHandlerService implements SubscriptionService {
    @Override
    public Response subscribe(Request request) {
        return null;
    }
}
