package tafat.framework.mockServices.classToService;

import tafat.framework.services.NotificationService;

public class NotificationHandlerService implements NotificationService {
    public NotificationHandlerService() {
    }

    @Override
    public void push(String username, String message) {

    }

    @Override
    public void broadcast(String message) {

    }
}
