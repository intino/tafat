package tafat.site.route.identification;

public interface Identification {
}
