package smartcities.natives;

import magritte.NativeCode;

public interface QCalculus extends NativeCode {

    double calculate(double area, double alpha);

}
