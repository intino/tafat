package tafat.natives;

import magritte.NativeCode;

public interface Check extends NativeCode {

    boolean check();

}
