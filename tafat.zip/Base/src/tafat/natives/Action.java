package tafat.natives;

import magritte.NativeCode;

public interface Action extends NativeCode {

    void execute();

}
