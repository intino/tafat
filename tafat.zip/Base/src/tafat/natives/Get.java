package tafat.natives;

import magritte.NativeCode;

public interface Get extends NativeCode {

    double get(String key);

}
