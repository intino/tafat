package tafat.natives;

import magritte.NativeCode;

public interface Function extends NativeCode {

    double calculate();
}
