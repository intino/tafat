package tafat.natives;

import magritte.NativeCode;

public interface Timeout extends NativeCode {

    int calculate();
}
