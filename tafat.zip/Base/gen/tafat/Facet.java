package tafat;

import magritte.primitives.*;

import magritte.wraps.*;


public class Facet extends magritte.wraps.Morph {
}
