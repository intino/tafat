package tafat;

import magritte.primitives.*;

import magritte.wraps.*;


public class StartJob extends tafat.JobAction {
}
