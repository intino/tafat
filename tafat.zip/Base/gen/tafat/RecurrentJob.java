package tafat;

import magritte.primitives.*;

import magritte.wraps.*;


public class RecurrentJob extends tafat.JobAction {
}
