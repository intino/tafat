package tafat;

import magritte.primitives.*;

import magritte.wraps.*;


public class EndJob extends tafat.JobAction {
}
