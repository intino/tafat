package tafat;

import magritte.primitives.*;

import magritte.wraps.*;


public class View extends magritte.wraps.Morph {
}
