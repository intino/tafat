package tafat;

import magritte.primitives.*;

import magritte.wraps.*;


public class Agent extends magritte.wraps.Morph {
}
