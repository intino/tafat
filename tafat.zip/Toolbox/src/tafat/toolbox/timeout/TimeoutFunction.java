package tafat.toolbox.timeout;

public interface TimeoutFunction {

    public long calculate();

}
