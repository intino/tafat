package tafat.toolbox;

public interface Action {

    public void execute();

}
