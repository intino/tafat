package tafat.toolbox;

public interface Checker {

    boolean check();

}
