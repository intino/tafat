package basetest.simplestatechart;

import magritte.primitives.*;

import magritte.wraps.*;


public class SimpleStateChart_Fridge extends basetest.simplestatechart.SimpleStateChart {
}
