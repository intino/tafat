package basetest;

import magritte.primitives.*;

import magritte.wraps.*;


public class Fridge extends magritte.wraps.Morph {
}
